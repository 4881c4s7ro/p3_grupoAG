def salude(nombre:str, apellido:str, edad:int = 25):
    print(f"Hola {nombre} {apellido}! Tu edad es: {edad}")
    
#salude("Franco", "Ruis Dias", 30)

#nombre_global= input("Ingrese el nombre: ")
#apellido_global= input("Ingrese el apellido: ")
#edad_global= int(input("Ingrese la edad: "))

#salude(apellido=apellido_global,nombre=nombre_global, edad=edad_global)

def retorno_saludo(nombre:str, apellido:str, edad:int = 25):
    return "Hola " + nombre + " " + apellido + "! Tu edad es: "+str(edad)

resultado = retorno_saludo("Franco", "Ruis Dias", 30)
print(resultado)