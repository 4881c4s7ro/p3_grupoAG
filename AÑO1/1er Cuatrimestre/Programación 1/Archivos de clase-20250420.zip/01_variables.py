mensaje_texto = 'Hola a todos esto es Programación I'
n = 17
calculo = 17  + 25

print(mensaje_texto)
print(n)
print(calculo)

# Paréntesis
# print(2 * (3 - 1)) # es 4 
# print((1 + 1)**(5 - 2)) # es 8. 

# # Exponenciación
# print(1 + 2**3) # es 9, no 27 
# print(2 * 3**2) #es 18 no 36.

# #Multiplicación y división
# print(2 * 3 - 1) #es 5, no 4 
# print(6 + 4 / 2) #es 8 no 5.

# grados = 180
# pi = 3.1415926535897932
# print(grados / 2 * pi)
# print(grados / 2 / pi)

# print(grados / (2 * pi))


import ctypes
print(id(42))

print(ctypes.cast(id(42), ctypes.py_object).value)