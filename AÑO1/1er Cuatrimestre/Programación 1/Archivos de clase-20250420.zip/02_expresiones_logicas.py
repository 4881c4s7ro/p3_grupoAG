variable1 = True
variable2 = False

print("variable1: " + str(variable1))
print("variable2: " + str(variable2))

print("expresión 1: " + str(variable1 and variable2))
print("expresión 2: " + str(variable1 or variable2))
print("expresión 3: " + str(not variable1))
