# ################
# # Diapositiva 3
# ################
# print ("""
# ################
# # Diapositiva 3
# ################""")

# print('Snap') # Comillas simples
# print("Crackle") # Comillas dobles
# print('''Boom!''') # Triple comillas simples
# print("""Quich!""") # Triple comillas dobles
# print(str(4.5)) # Conversión de valores a string

# print("Calle O' Connor")
# print('"Hoy puede ser un gran día!"')

# # ################
# # # Diapositiva 4
# # ################
# print ("""
# ################
# # Diapositiva 4
# ################""")

# # print("Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
# #      Nullam placerat, sem ut luctus consectetur, ex elit cursus orci, eget tempus purus arcu vel risus.") #error de sintaxis

# print("""Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
# Nullam placerat, sem ut luctus consectetur, ex elit cursus orci, eget tempus purus arcu vel risus.""")

# ################
# # Diapositiva 5
# ################
# print ("""
# ################
# # Diapositiva 5
# ################""")

# november_rain ="Nothin' lasts forever\nAnd we both know hearts can change\nAnd it's hard to hold a candle\nIn the cold November rain"
# print(november_rain)

# print("Sweet Child\t O' mine")

# # ################
# # # Diapositiva 6
# # ################
# print ("""
# ################
# # Diapositiva 6
# ################""")

letras = 'abcdefghijklmnopqrstuvwxyz'
# print(letras[0])
# print(letras[1])
# print(letras[-1])
# print(letras[-2])
# print(letras[5])

# print(letras[100]) # error string index out of range

################
# Diapositiva 8
################
# print ("""
# ################
# # Diapositiva 8
# ################""")

# print(letras[:]) # el string completo.
# print(letras[20:] )# desde 20 hasta el final.
# print(letras[12:15])  # desde 12 hasta 14.
# print(letras[-3:]) # los últimos 3 caracteres.
# print(letras[::7])# de principio a fin salteando de a 7 caracteres. 
# print(letras[::-1]) # empieza al final y con paso negativo llega al principio.

# ################
# # Diapositiva 9
# ################
print ("""
################
# Diapositiva 9
################""")

print(len(letras))
print(len("prueba" + letras))